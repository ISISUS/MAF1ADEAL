# Universal-Mobile-Spyware
Access iPhone &amp; Android Phones Remotely. It is very easy to run. All you need to instal remotely is the target's phone number. I am not leaving files public here because of abuse and possible detection by security experts. 
Easily access a target PC (Windows Only) with a PDF file, no complications.
# secrettruthhackers [at] gmail 
# WhatsApp; +13658002686
