package com.wanjian.sak.system.canvaspool;

import android.graphics.Canvas;

public interface CanvasRecycleListener {
  void onRecycle(Canvas canvas);
}