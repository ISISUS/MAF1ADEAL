package com.wanjian.sak.layer;

import com.wanjian.sak.converter.ISizeConverter;

public interface ISize {
  void onSizeConvertChange(ISizeConverter converter);
}
