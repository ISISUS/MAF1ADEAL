package com.wanjian.sak.system.input;

public class InputEventReceiverHolder {

}
