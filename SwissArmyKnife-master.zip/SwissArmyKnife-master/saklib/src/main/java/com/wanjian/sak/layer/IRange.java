package com.wanjian.sak.layer;

public interface IRange {
  void onStartRangeChange(int start);
  void onEndRangeChange(int start);
}
