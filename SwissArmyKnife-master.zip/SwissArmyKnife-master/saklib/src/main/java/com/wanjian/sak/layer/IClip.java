package com.wanjian.sak.layer;

public interface IClip {
  void onClipChange(boolean clip);
}
