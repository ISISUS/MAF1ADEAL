package com.wanjian.sak.converter;


/**
 * Created by wanjian on 2017/2/20.
 */

public class Size {

    private Size() {
    }

    public Size(int length, String unit) {

    }

    public static Size obtain() {

        return null;
    }

    public float getLength() {
        return 0;
    }

    public Size setLength(float length) {
        return this;
    }

    public String getUnit() {
        return null;
    }

    public Size setUnit(String unit) {
        return this;
    }

}
