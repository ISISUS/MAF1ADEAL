package com.wanjian.sak;

import android.app.Application;

import com.wanjian.sak.config.Config;

/**
 * Created by wanjian on 2017/2/20.
 */

public class SAK {

    public static void init(Application application, Config config) {

    }

    private SAK() {
    }

    public static void unInstall() {

    }

}
