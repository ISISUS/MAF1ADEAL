package android.view;

public class HardwareLayer {
  boolean isEnabled() {
    return false;
  }
}
