package android.view;

import java.util.List;

public class InputEventCompatProcessor {
  public List<InputEvent> processInputEventForCompatibility(InputEvent e) {
    return null;
  }
}
