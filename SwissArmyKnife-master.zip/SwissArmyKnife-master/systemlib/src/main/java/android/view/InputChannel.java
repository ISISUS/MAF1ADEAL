package android.view;

public class InputChannel {
}
