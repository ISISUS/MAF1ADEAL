package android.graphics;

public final class FrameInfo {

  public void markDrawStart() {
  }


}