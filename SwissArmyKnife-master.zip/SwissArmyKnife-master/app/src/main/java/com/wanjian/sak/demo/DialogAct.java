package com.wanjian.sak.demo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by wanjian on 2017/4/1.
 */

public class DialogAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.dialog_act);
    }
}
