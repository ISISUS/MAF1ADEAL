package com.wanjian.dialog;

import android.app.Activity;

public class TransparentActivity extends Activity {
}
