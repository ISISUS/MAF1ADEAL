# PhishBowl
 Python script to detect phishing bots targeting major Canadian banks and getting notified via a telegram channel.

 Current limitation: Gets phishing links from one phishing feed source.

# Requirements
Install the requirements using **pip install -r requirements.txt**

# Todo
