                      ▄▄▄       █    ██ ▄▄▄█████▓ ▒█████    ██████  ███▄    █  ██▓  █████▒ █████▒
                     ▒████▄     ██  ▓██▒▓  ██▒ ▓▒▒██▒  ██▒▒██    ▒  ██ ▀█   █ ▓██▒▓██   ▒▓██   ▒ 
                     ▒██  ▀█▄  ▓██  ▒██░▒ ▓██░ ▒░▒██░  ██▒░ ▓██▄   ▓██  ▀█ ██▒▒██▒▒████ ░▒████ ░ 
                     ░██▄▄▄▄██ ▓▓█  ░██░░ ▓██▓ ░ ▒██   ██░  ▒   ██▒▓██▒  ▐▌██▒░██░░▓█▒  ░░▓█▒  ░ 
                      ▓█   ▓██▒▒▒█████▓   ▒██▒ ░ ░ ████▓▒░▒██████▒▒▒██░   ▓██░░██░░▒█░   ░▒█░    
                      ▒▒   ▓▒█░░▒▓▒ ▒ ▒   ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▓▒ ▒ ░░ ▒░   ▒ ▒ ░▓   ▒ ░    ▒ ░    
                       ▒   ▒▒ ░░░▒░ ░ ░     ░      ░ ▒ ▒░ ░ ░▒  ░ ░░ ░░   ░ ▒░ ▒ ░ ░      ░      
                       ░   ▒    ░░░ ░ ░   ░      ░ ░ ░ ▒  ░  ░  ░     ░   ░ ░  ▒ ░ ░ ░    ░ ░    
                           ░  ░   ░                  ░ ░        ░           ░  ░                 
                                                                       AutoSniff v1.2 by LYSYyy

# AutoSniff
AutoSniff (AS) is a program that calls the most popular tools for sniffing on network traffic. AS combines and automates tools such as: Ettercap, WireShark, SSLstrip, DNS2Proxy and URLsnarf. It's all automatically and quickly! Available in Linux!

## AUTOSNIFF FUNCTION:

- Four sniffing levels

- Inclusion 5 most popular tools for sniffing

- Automatic downloading and install required tools

- Creating a session

- Two languages available: PL / EN

## HOW TO INSTALL?

1. ```git clone https://github.com/LYSYyy/AutoSniff.git```
2. ```cd AutoSniff```
3. ```chmod +x setup.sh && ./setup.sh```

---------------------------------------------------------------

Please report all errors and possible suggestions!
Thank you :)
