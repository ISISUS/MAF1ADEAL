<p align="center">
  <img src="https://raw.githubusercontent.com/UndeadSec/Enigma/master/Images/enigma.png">
</p>

<h1 align="center">Enigma</h1>
<p align="center">
  Multiplatform payload dropper.
</p>

## VIDEO DEMO
<p align="center">
<a href="https://youtu.be/ZszpJAF7Ti8">
  <img src="https://raw.githubusercontent.com/UndeadSec/Enigma/master/Images/video.png" />
</a></p>

### CLONE
```
git clone https://github.com/UndeadSec/Enigma.git
```

### RUNNING
```
cd Enigma
```

```
python enigma.py
or
python3 enigma3.py
```
## DISCLAIMER
<p align="center">
   TO BE USED FOR EDUCATIONAL PURPOSES ONLY
</p>

The use of the Enigma is COMPLETE RESPONSIBILITY of the END-USER. Developer assume NO liability and are NOT responsible for any misuse or damage caused by this program.

"DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
Taken from [LICENSE](LICENSE).

### PREREQUISITES

* python 2.7 for enigma.py
* python 3.x for enigma.py
* metasploit
* msfvenom

## TESTED ON
[![Kali)](https://www.google.com/s2/favicons?domain=https://www.kali.org/)](https://www.kali.org) **Kali Linux - ROLLING EDITION**

## Donation
If you liked our work and want to support us, you can donate :D

<img src="https://raw.githubusercontent.com/UndeadSec/Enigma/master/Images/donation.png"></img>

Bitcoin Address: 1EmJ5KiAKzpyqGGHopAq9qukrVPS47T9bA

### SCREENSHOT
![Shot](https://github.com/UndeadSec/Enigma/blob/master/Images/sc.png)
