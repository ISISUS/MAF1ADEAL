def default_graph_api_response_headers
  {
    'Content-Type' => 'text/javascript; charset=UTF-8'
  }
end
