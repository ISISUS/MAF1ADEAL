module Facebook
  module Messenger
    #
    # @return [String] Define the version of gem.
    VERSION = '2.0.1'.freeze
  end
end
