## Bablo Bot

Бот [Bablo Bot](https://t.me/bablomaker_bot) позволяет выполнять задания и получать вознаграждения в качестве долларов на виртуальном счету.
![Image](https://telegra.ph/file/cbc2f155c0ceb9a2f1ceb.png)
Python, Flask, pyTelegramBotApi, etc.

У бота есть панелья администратора, в которой можно управлять ботом
PHP, VueJs, Fetch, Axios
![Image](https://telegra.ph/file/1964b2b86005cd58bf723.png)
![Image](https://telegra.ph/file/0d133fc0eaf3e8a9112d7.png)
![Image](https://telegra.ph/file/e7eee2059ab4f1ed0f611.png)
