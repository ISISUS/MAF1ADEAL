# v1.0.4
First version with java-oom.

# v1.0.5
Enhancement
- Add custom root dir validity check.

Bug fix
- StripHprofHeapDumper bugfix.

# v1.1.0
Enhancement
- Add heap max ratio and force trigger.
- Add support for x86.

Bug fix
- Hardcode cacheDir path on unpredictable case.
- Add try-catch in abnormal start, delete abnormal json file.


