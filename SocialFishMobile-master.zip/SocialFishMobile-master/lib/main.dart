import 'package:flutter/material.dart';

import 'package:socialfish/socialfish.dart';

void main() {
//  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]); //Portrait mode only
  runApp(SocialFish());
}
