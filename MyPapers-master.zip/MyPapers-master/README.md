This repository is intended to host my research papers. Put it on watch if you would like to read more from me.

- [Bypassing XSS Detection Mechanisms](https://github.com/s0md3v/MyPapers/tree/master/Bypassing-XSS-detection-mechanisms) [[Download PDF](https://github.com/s0md3v/MyPapers/raw/master/Bypassing-XSS-detection-mechanisms/Bypassing-XSS-Detection-Mechanisms.pdf)]
- [A Phonetic Approach to Calculate Linguistic Information in Text](https://github.com/s0md3v/MyPapers/tree/master/A%20Phonetic%20Approach%20to%20Calculate%20Linguistic%20Information%20in%20Text) [[Download PDF](https://github.com/s0md3v/MyPapers/blob/master/A%20Phonetic%20Approach%20to%20Calculate%20Linguistic%20Information%20in%20Text/A%20Phonetic%20Approach%20to%20Calculate%20Linguistic%20Information%20in%20Text.pdf)]
