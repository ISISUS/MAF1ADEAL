<?php

class Miziagui_Fastcash_Model_Resource_Setup extends Mage_Eav_Model_Entity_Setup 
{
    
}