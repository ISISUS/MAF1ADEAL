UPDATE = {
    "update_id": 435433658,
    "message": {
        "message_id": 1896,
        "date": 1584858196,
        "chat": {
            "id": 544762280,
            "type": "private",
            "username": "merc1er",
            "first_name": "Corentin",
            "last_name": "Mercier",
        },
        "text": "/withdraw all bitcoincash:qp5sm5u7l28rxg2eqmfhhnk3tk2cxm0j6y53fzpcj",
        "entities": [{"type": "bot_command", "offset": 0, "length": 9}],
        "caption_entities": [],
        "photo": [],
        "new_chat_members": [],
        "new_chat_photo": [],
        "delete_chat_photo": False,
        "group_chat_created": False,
        "supergroup_chat_created": False,
        "channel_chat_created": False,
        "from": {
            "id": 544762280,
            "first_name": "Corentin",
            "is_bot": False,
            "last_name": "Mercier",
            "username": "merc1er",
            "language_code": "en",
        },
    },
    "_effective_message": {
        "message_id": 1896,
        "date": 1584858196,
        "chat": {
            "id": 544762280,
            "type": "private",
            "username": "merc1er",
            "first_name": "Corentin",
            "last_name": "Mercier",
        },
        "text": "/withdraw all bitcoincash:qp5sm5u7l28rxg2eqmfhhnk3tk2cxm0j6y53fzpcj",
        "entities": [{"type": "bot_command", "offset": 0, "length": 9}],
        "caption_entities": [],
        "photo": [],
        "new_chat_members": [],
        "new_chat_photo": [],
        "delete_chat_photo": False,
        "group_chat_created": False,
        "supergroup_chat_created": False,
        "channel_chat_created": False,
        "from": {
            "id": 544762280,
            "first_name": "Corentin",
            "is_bot": False,
            "last_name": "Mercier",
            "username": "merc1er",
            "language_code": "en",
        },
    },
}


# Addresses
ADDRESS = "bitcoincash:qr02vc2t5yr9fe4ujdpkg99d5d0dgxstfqtgxg7umu"
ADDR_NO_PREFIX = "qr02vc2t5yr9fe4ujdpkg99d5d0dgxstfqtgxg7umu"
