//
//  SPEmailASAccount.h
//  SpyPhone
//
//  Created by Nicolas Seriot on 11/20/09.
//  Copyright 2009. 
//  Licensed under GPL 2.0 http://www.gnu.org/licenses/gpl-2.0.txt
//

#import "SPEmailAccount.h"

@interface SPEmailASAccount : SPEmailAccount {
	
}

@end
