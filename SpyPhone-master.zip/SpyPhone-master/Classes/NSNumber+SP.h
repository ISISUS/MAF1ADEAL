//
//  NSNumber+SL.h
//  SpotLook
//
//  Created by Nicolas Seriot on 31.03.08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSNumber (SP)

- (NSString *)prettyBytes;

@end
