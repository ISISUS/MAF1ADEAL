package transfer.account.withdraw

data class Withdrawal(val accountId: String?, val amount: Long)