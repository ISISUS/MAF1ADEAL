package transfer.account.deposit

data class Deposit(val accountId: String?, val amount: Long)