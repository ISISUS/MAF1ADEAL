package transfer.account

data class AccountId(val id: String)