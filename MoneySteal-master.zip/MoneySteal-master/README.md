# MoneySteal
A Minecraft plugin that allows players to steal a percentage of money from others by killing them.
