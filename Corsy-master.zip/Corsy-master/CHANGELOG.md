#### 0.2-beta
- Major bug fixes
- Unicode support
- Added `unescaped regex` test

#### 0.1-beta
initial release (with breaking bugs)
