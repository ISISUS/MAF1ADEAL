# Changelog

## 1.4

- Updates to Chinese version by [tiiime](https://github.com/tiiime), [neal1991](https://github.com/neal1991), and [yizhiheng](https://github.com/yizhiheng). 

## 1.3

- Add Chinese versions as README.zh.md and appendix.zh.md thanks to [neal1991](https://github.com/neal1991).

## 1.2

- Add MacOS/OSX support via the [appendix](appendix.md), thanks [harshpatel991](https://github.com/harshpatel991)!

## 1.1

- Add [appendix](appendix.md)
	- Handshake capture with `wlandump-ng`
	- Programatic wordlist generation with `crunch`
	- Macchanger info

## 1.0

- Original tutorial with rolling changes for small updates and typos, etc...
