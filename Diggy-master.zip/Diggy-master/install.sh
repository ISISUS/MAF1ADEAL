cp diggy.sh /usr/bin/diggy
chmod +x /usr/bin/diggy
echo "Everything is setup! Enter 'diggy <path to apk>' in terminal to use diggy"
