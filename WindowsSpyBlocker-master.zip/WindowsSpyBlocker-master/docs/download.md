# Download

WindowsSpyBlocker is available on [GitHub releases]({{ config.repo_url }}releases/latest) page.

[Download WindowsSpyBlocker.exe]({{ config.repo_url }}releases/download/{{ git.tag | trim('v') }}/WindowsSpyBlocker.exe){: .md-button .md-button--primary }

But also:

* As a [Chocolatey package](https://chocolatey.org/packages/windowsspyblocker) that will allow you to benefit from automatic updates
* As a [Scoop](https://scoop.sh/) package (`windowsspyblocker`) that will allow you to benefit from automatic updates
