# Dev menu

## Preview

Dev menu mainly concerns developers or curious people who would like to contribute to WindowsSpyBlocker.
Here several applications are used by WindowsSpyBlocker to generate, capture and audit traffic.

![](../../assets/app/dev/menu.png)

## Menus

* _QEMU_
* [**Proxifier**](proxifier.md)
* [**Sysmon**](sysmon.md)
* [**Wireshark**](wireshark.md)
* _Test_
* _Diff_
* _Merge_
* _Extract data_
