# Telemetry menu

## Preview

Telemetry menu allows you to apply rules to the Windows firewall and modify the NCSI.

![](../../assets/app/telemetry/menu.png)

## Menus

* [**Firewall**](firewall.md)
* [**NCSI**](ncsi.md)
