# Kaspersky Firewall

!!! info
    Kaspersky blocking rules available at [{{ config.repo_url }}tree/master/data/kaspersky]({{ config.repo_url }}tree/master/data/kaspersky)

[Kaspersky Firewall](https://help.kaspersky.com/KSVLA/5.0/en-US/149707.htm) a proprietary firewall solution.

You can integrate data specifically generated for Kaspersky Firewall from `data/kaspersky` folder.
