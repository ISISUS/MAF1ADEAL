# ESET Firewall

!!! info
    ESET blocking rules available at [{{ config.repo_url }}tree/master/data/eset]({{ config.repo_url }}tree/master/data/firewall)

[ESET Firewall](https://www.eset.com/us/firewall/) a proprietary firewall solution.

You can integrate data specifically generated for ESET Firewall from `data/eset` folder.

Here is a quick example:

![](../assets/blocking-rules/eset/eset-firewall.png)
