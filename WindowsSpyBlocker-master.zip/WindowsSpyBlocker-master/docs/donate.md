**WindowsSpyBlocker** :shield: is free and open source and always will be.

All kinds of contributions are welcome! The most basic way to show your support is to
[star the project]({{ config.repo_rul }}), or to raise issues.

You can also support this project by [**becoming a sponsor on GitHub**](https://github.com/sponsors/crazy-max) or
by making a [Paypal donation](https://www.paypal.me/crazyws) to ensure this journey continues indefinitely!
